<HTML>
<head>
	<title> Piao's DayLog </title>
	<META http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="mystyle.css"/>
</head>

<body>
	<header>
		
		<h1> Piao's Day Log</h1>
		
		
	</header> <!--  **********************************header end here -->
		<hr>
		<br>
	<aside id="left">
	<h4>KeyWords</h4>	<!-- *************************need DB -->
		
		<ul>
			<li><a target="iframe1" href="GetFromKeywords.php">#c</a></li>
		</ul>
		
	</aside> <!-- ************************************aside end here  -->
	
	<section id="main">
		<article id="article1">
			<iframe name="iframe1" src="@ShowPosts.php "></iframe>
		</article>
	</section> <!-- **********************************section end here -->
	
	<footer>
	<p>all right reserved by Piao</p>
	</footer> <!-- ***********************************footer end here -->
	
</body> <!-- *****************************************body end here -->

</HTML>